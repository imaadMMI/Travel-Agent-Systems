package F28DA_CW2;

public class FlyingPlannerException extends Exception {

	private static final long serialVersionUID = -4630591510236199827L;

	public FlyingPlannerException(String message) {
		super(message);
	}
}
