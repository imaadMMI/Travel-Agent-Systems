package F28DA_CW2;

public interface IAirportPartB {

	public String getCode();
	
	public String getName();
	
}
